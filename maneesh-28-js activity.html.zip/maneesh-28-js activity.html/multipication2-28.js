function mul(x, y) {

    let z = x * y;
    return z;
}