function peri1(r){ 
    result=3.14*r*r;
    document.getElementById("peric").innerHTML="Result="+result;

}function peri2(l,b){
    result2=(l+b)*2;
    document.getElementById("perir").innerHTML="Result2="+result2;

}function peri(a){
    result3=4*a;
    document.getElementById("peris").innerHTML="Result3="+result3;

}